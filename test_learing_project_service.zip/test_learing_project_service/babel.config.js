module.exports = {
  presets: ['@vue/app'],
  plugins: ['@babel/plugin-transform-runtime'],
  env: {
    test: {
      presets: [['@babel/env']],
      plugins: ['@babel/plugin-transform-runtime'],
    },
    jsdom: {},
  },
};
