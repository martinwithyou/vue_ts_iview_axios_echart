export default class {
  public static selectMore(query: object, page?: Page, orders?: OrderBy[]) {
    return {
      query,//查询条件
      page,//查询页数
      orders,
    };
  }
  public static pager(index: number = 0, size: number = 20): Page {
    return {
      page_index: index,
      page_size: size,//查询的条尺寸
    };
  }
  public static order(column: string, isDesc: boolean): OrderBy {
    return {
      column_name: column,
      desc: isDesc,
    };
  }
}

export interface Page {
  page_index: number;
  page_size: number;
}

export interface OrderBy {
  column_name: string;
  desc: boolean;
}
