<template>
  <div class="about">
    <Hello :msg="gogo"/>
    <World :msg="gogo"/>
    <SelfDefine :msg="gogo"/>
  </div>
</template>
<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import Hello from '@/components/Hello.vue'; // @ is an alias to /src
import World from '@/components/World.vue'; // @ is an alias to /src
import SelfDefine from '@/components/SelfDefine.vue'; // @ is an alias to /src
@Component({
  components: {
    Hello,
    World,
    SelfDefine
  },
})
export default class Home extends Vue {
  public gogo:any = "";
}
</script>
