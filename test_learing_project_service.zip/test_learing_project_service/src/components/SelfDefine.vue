<template>
  <div class="hello">
    <Row>
      <Col span="6" style="padding-right:10px;font-size:16px;">
        第三方包
      </Col>
      <Col span="4" style="padding-right:10px">
        
      </Col>
    </Row>
  </div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';

@Component({
  components: {},
  inject: ["fixflowGroupService"]
})
export default class HelloWorld extends Vue {
  @Prop() private msg!: string;
  public model14:any = [];
  public options2:any = [
    {
      id:1,
      name:"111"
    },
    {
      id:2,
      name:"222"
    },
    {
      id:3,
      name:"333"
    },
    {
      id:1,
      name:"111"
    },
    {
      id:2,
      name:"222"
    },
    {
      id:3,
      name:"333"
    },
  ];
  public loading2:boolean = false;
  public mounted() {

    const { removeRepetition } = require('removerepetition');
    let resArray = removeRepetition( this.options2 );
    console.log( resArray );

  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
