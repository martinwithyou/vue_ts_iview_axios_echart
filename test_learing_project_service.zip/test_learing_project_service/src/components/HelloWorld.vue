<template>
  <div class="hello">
    <Table 
      stripe 
      :columns="columns1" 
      :data="data1">
    </Table>
  </div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';

@Component({
  components: {},
  inject: ["fixflowGroupService"]
})
export default class HelloWorld extends Vue {
  @Prop() private msg!: string;
  public self:any = 'self data';
  public columns1:any = [
            {
              title: 'Name',
              key: 'name'
            },
            {
              title: 'Age',
              key: 'age'
            },
            {
              title: 'Address',
               key: 'address'
            }
          ];
  public  data1:any =[
            {
              name: 'John Brown',
              age: 18,
              address: 'New York No. 1 Lake Park',
              date: '2016-10-03'
            },
            {
              name: 'Jim Green',
              age: 24,
              address: 'London No. 1 Lake Park',
              date: '2016-10-01'
            },
            {
              name: 'Joe Black',
              age: 30,
              address: 'Sydney No. 1 Lake Park',
              date: '2016-10-02'
            },
            {
              name: 'Jon Snow',
              age: 26,
              address: 'Ottawa No. 2 Lake Park',
              date: '2016-10-04'
            }
          ];
  public mounted() {
    // console.log( this);
    let res:any = this.fixflowGroupService.selectRuleAttrDataById(1);
    // console.log(this);
  }
}
</script>

<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
