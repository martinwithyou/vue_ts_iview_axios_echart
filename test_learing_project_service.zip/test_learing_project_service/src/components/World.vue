<template>
  <div class="hello">
    <div class="out">
      <h1>chart</h1>
      <div ref="myEchart" class="myEchart"></div>
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';
import echarts from 'echarts'
@Component({
  components: {},
  inject: ["fixflowGroupService"]
})
export default class HelloWorld extends Vue {
  @Prop() private msg!: string;
  public self:any = 'self data';
  public chart:any = {};
  public mounted() {
    this.initChart();
    let res:any = this.fixflowGroupService.selectRuleAttrDataById(1);
  }
  public initChart() {
      let obj:any =this.$refs.myEchart;
      this.chart = echarts.init(obj);
      // 把配置和数据放这里
      this.chart.setOption({
        color: ['#3398DB'],
        tooltip: {
          trigger: 'axis',
          axisPointer: { // 坐标轴指示器，坐标轴触发有效
            type: 'shadow' // 默认为直线，可选为：'line' | 'shadow'
          }
        },
        grid: {
          left: '3%',
          right: '4%',
          bottom: '3%',
          containLabel: true
        },
        xAxis: [{
          type: 'category',
          data: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
          axisTick: {
            alignWithLabel: true
          }
        }],
        yAxis: [{
          type: 'value'
        }],
        series: [{
          name: '直接访问',
          type: 'bar',
          barWidth: '60%',
          data: [10, 52, 200, 334, 390, 330, 220]
        }]
      })
    }
}
</script>

<style scoped>
.out{
  width:100%; 
  height:600px;
  background-color:#ffffff;
  border:0px solid red;
  overflow:auto;
  margin-top:20px;
}
.myEchart{
  border: 1px solid #d9d9d9;
  background: #ffffff;
  width:500px;
  height:500px;
}
</style>
