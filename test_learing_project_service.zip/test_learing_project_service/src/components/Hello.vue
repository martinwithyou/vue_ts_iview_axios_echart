<template>
  <div class="hello">
    <Row>
      <Col span="6" style="padding-right:10px;font-size:16px;">
        多选下拉案例
      </Col>
      <Col span="14">
        <Select
            v-model="model14"
            multiple
            filterable
            remote
            :remote-method="remoteMethod2"
            @on-open-change="cleckSearchInput"
            @on-change="selectOne"
            :loading="loading2">
            <Option 
              v-for="(option, index) in options2" 
              :value="option.label" 
              :key="index">
              {{option.label}}
            </Option>
        </Select>
      </Col>
      <Col span="4" style="padding-right:10px">
        <Button 
          type="primary" 
          @click="submitMothod">
          提交
        </Button>
      </Col>
    </Row>
  </div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';

@Component({
  components: {},
  inject: ["fixflowGroupService"]
})
export default class HelloWorld extends Vue {
  @Prop() private msg!: string;
  public model14:any = [];
  public options2:any = [];
  public loading2:boolean = false;
  public selectOne(value: any){
    // console.log(value)
  }
  public cleckSearchInput(){
            this.loading2 = true;
            setTimeout(() => {
                this.loading2 = false;
                fetch('http://jsonplaceholder.typicode.com/comments')
                  .then(response => response.json())
                  .then((json) => {
                    const options2 = json.map((item: any) => {
                      return {
                        value: item.id,
                        label: item.name
                      };
                    });
                    this.options2 = options2.filter((item: any )=> item.label.toLowerCase().indexOf("") > -1);
                  })
              
            }, 200);
  }
  public remoteMethod2(query: any){
          if (query !== '') {
            this.loading2 = true;
            setTimeout(() => {
                this.loading2 = false;
                fetch('http://jsonplaceholder.typicode.com/comments')
                  .then(response => response.json())
                  .then((json) => {
                    const options2 = json.map((item:any) => {
                      return {
                        value: item.id,
                        label: item.name
                      };
                    });
                    this.options2 = options2.filter( (item:any) => item.label.toLowerCase().indexOf(query.toLowerCase()) > -1);
                  })
              
            }, 200);
          } else {
            this.options2 = [];
          }
         
  }
  public submitMothod(nodesc: any){
    // this.$Message.error({ content: JSON.stringify(this), duration: 3 });
    // this.$Message.error('This is an error tip');
    // this.$Notice.open({
    //   title: 'Notification title',
    //   desc: nodesc ? '' : 'Here is the notification description. Here is the notification description. '
    // });
    let res:any = JSON.stringify(this.options2);
    this.$Message.info({ content: res, duration: 3 });
  }
  public mounted() {
    // console.log( this);
    // let res:any = this.fixflowGroupService.selectRuleAttrDataById(1);
    // console.log(this);
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
