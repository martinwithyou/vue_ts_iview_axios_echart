import Vue from 'vue';
import {
  FlowTypeService,
  FixflowGroupService,
  FixflowHistoryService,
  FixflowManageService,
  FixflowPreviewService,
  FixflowVirtualRuntime,
  FixflowAppIdManagmentService,
} from './services/publish';
import {
  TaskService,
  CommandService,
  UserService,
  LogService,
  ProcessService,
  EmployeeService,
  DimissionService,
} from '@/services/manage';
import {
  RuleattrService,
  RuleattrdataService,
  RuleroleService,
  RuleroleuserService,
  RuleManagementService
} from '@/services/rules';

declare module 'vue/types/vue' {
  interface Vue {
    flowTypeService: FlowTypeService;
    fixflowGroupService: FixflowGroupService;
    fixflowHistoryService: FixflowHistoryService;
    fixflowManageService: FixflowManageService;
    fixflowPreviewService: FixflowPreviewService;
    fixflowVirtualRuntime: FixflowVirtualRuntime;
    fixflowAppIdManagmentService: FixflowAppIdManagmentService;

    processService: ProcessService;
    userService: UserService;
    taskService: TaskService;
    commandService: CommandService;
    logService: LogService;
    employeeService: EmployeeService;
    dimissionService: DimissionService;

    ruleattrService: RuleattrService;
    ruleattrdataService: RuleattrdataService;
    ruleroleService: RuleroleService;
    ruleroleuserService: RuleroleuserService;
    ruleManagementService:RuleManagementService;
  }
}
