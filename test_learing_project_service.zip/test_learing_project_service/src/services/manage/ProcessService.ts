import Utils from '../../utils';
import qb, { OrderBy } from '../../query-builder';

export default class {
  private utils: any;
  constructor(apiPath: string) {
    this.utils = new Utils(apiPath);
  }
  public async getProcessInstance(params: any) {
    const result = await this.utils.post('/process/getProcessInstance', params);
    return result.data;
  }
  public async getFlowVariable(params: any) {
    const result = await this.utils.post('/process/getFlowVariable', params);
    return result.data;
  }
  public async getProcessDefData(
    query: any,
    pageIndex: number,
    pageSize: number,
    orderBys?: OrderBy[]
  ) {
    const result = await this.utils.post(
      '/process/getProcessDefData',
      qb.selectMore(query, qb.pager(pageIndex, pageSize), orderBys)
    );
    return result.data;
  }
}
