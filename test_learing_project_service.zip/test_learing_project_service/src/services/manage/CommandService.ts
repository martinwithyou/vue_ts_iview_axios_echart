import Utils from '../../utils';

export default class {
  private utils: any;
  constructor(apiPath: string) {
    this.utils = new Utils(apiPath);
  }


}
