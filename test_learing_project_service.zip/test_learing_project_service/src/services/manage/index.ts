import UserService from './UserService';
import TaskService from './TaskService';
import ProcessService from './ProcessService';
import CommandService from './CommandService';
import LogService from './LogService';
import EmployeeService from './EmployeeService';
import DimissionService from './DimissionService';

const apiPath:any = process.env.VUE_APP_API_MANAGE;
const userService = new UserService(apiPath);
const processService = new ProcessService(apiPath);
const taskService = new TaskService(apiPath);
const commandService = new CommandService(apiPath);
const logService = new LogService(apiPath);
const employeeService = new EmployeeService(apiPath);
const dimissionService = new DimissionService(apiPath);

export {
  UserService,
  TaskService,
  ProcessService,
  CommandService,
  LogService,
  EmployeeService,
  DimissionService,
  userService,
  taskService,
  processService,
  commandService,
  logService,
  employeeService,
  dimissionService,
};
