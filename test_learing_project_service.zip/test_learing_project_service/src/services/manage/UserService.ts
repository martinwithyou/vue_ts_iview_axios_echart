import Utils from '../../utils';
import qb, { OrderBy } from '../../query-builder';

export default class {
  private utils: any;
  constructor(apiPath: string) {
    this.utils = new Utils(apiPath);
  }
}
