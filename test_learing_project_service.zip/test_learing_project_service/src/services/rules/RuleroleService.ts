import Utils from '../../utils';
import qb, { OrderBy } from '../../query-builder';

export default class {
  private utils: any;
  constructor(apiPath: string) {
    this.utils = new Utils(apiPath);
  }
  // 条件查询列表
  public async ruleRolePageList(query: any, pageIndex: number, pageSize: number, orderBys?: OrderBy[]) {
    const result = await this.utils.post(
      '/ruleRole/selectRuleRolePageList',
      qb.selectMore(query, qb.pager(pageIndex, pageSize), orderBys)
    );
    return this.utils.getActionResult(result);
  }
  // id查询列表
  public async selectTagById(id: any) {
    const result = await this.utils.post('/ruleRole/getRuleRoleById?id' + id);
    return this.utils.getActionResult(result);
  }
  // 新增
  public async addRuleRole(param: any) {
    const result = await this.utils.post('/ruleRole/addRuleRole', param);
    return this.utils.getActionResult(result);
  }
  // 更新
  public async updateRuleRole(param: any) {
    const result = await this.utils.post('/ruleRole/updateRuleRole', param);
    return this.utils.getActionResult(result);
  }
  // 删除
  public async delRuleRoleById(param: any) {
    const result = await this.utils.post('/ruleRole/delRuleRoleById?id=' + param);
    return this.utils.getActionResult(result);
  }
}
