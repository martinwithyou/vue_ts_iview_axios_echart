import Utils from '../../utils';
import qb, { OrderBy } from '../../query-builder';

export default class {
  private utils: any;
  constructor(apiPath: string) {
    this.utils = new Utils(apiPath);
  }
  // id查询列表
  public async selectEmployeeInfoByRoleId(rid: any) {
    const result = await this.utils.post(
      '/ruleRoleUser/selectEmployeeInfoByRoleId?role_id=' + rid
    );
    return this.utils.getActionResult(result);

  }
  // id查询员工角色列表
  public async listUsersInfoByRoleId(eid: any) {
    const result = await this.utils.post(
      '/ruleRoleUser/listUsersInfoByRoleId?role_id=' + eid
    );
    return this.utils.getActionResult(result);

  }
  // 新增
  public async add(param: any) {
    const result = await this.utils.post(
      '/ruleRoleUser/addRoleUserRelation',
      param
    );
    return this.utils.getActionResult(result);

  }
  // 更新
  public async updateRoleEmployeeRelation(param: any) {
    const result = await this.utils.post(
      '/ruleRoleUser/updateRoleEmployeeRelation',
      param
    );
    return this.utils.getActionResult(result);

  }
  // 删除
  public async delRuleRoleById(param: any) {
    const result = await this.utils.post(
      '/ruleRoleUser/delRoleUserRelation', param
    );
    return this.utils.getActionResult(result);

  }
  // user select
  public async getEmployeesInfo(param: any) {
    const result = await this.utils.post('/employee/getEmployeesInfo', param);
    return this.utils.getActionResult(result);
  }
}
