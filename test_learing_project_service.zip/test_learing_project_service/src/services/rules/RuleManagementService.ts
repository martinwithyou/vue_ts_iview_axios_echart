import Utils from '../../utils';
import qb, { OrderBy } from '../../query-builder';
export default class {
  private utils: any;
  constructor(apiPath: string) {
    this.utils = new Utils(apiPath);
  }
  // 模糊查询规则
  public async ruleLookup(
    query: any,
    pageIndex: number,
    pageSize: number,
    orderBys?: OrderBy[]
  ) {
    const result = await this.utils.post(
      '/rule/lookup',
      qb.selectMore(query, qb.pager(pageIndex, pageSize), orderBys)
    );
    return this.utils.getActionResult(result);
  }
  // 新加规则
  public async ruleAdd(param: any) {
    const result = await this.utils.post('/rule/add', param);
    return this.utils.getActionResult(result);
  }
  // 查询规则
  public async ruleGet(param:any) {
    const result = await this.utils.post(
      '/rule/get',
      param
    );
    return this.utils.getActionResult(result);
  }
  // 更新规则，维度修改顺序
  public async ruleUpdate(param: any) {
    const result = await this.utils.post(
      '/rule/update',
      param
    );
    return this.utils.getActionResult(result);
  }
  // 添加规则数据
  public async applicantRecordAdd(param: any) {
    const result = await this.utils.post(
      '/applicantRecord/add',
      param
    );
    return this.utils.getActionResult(result);
  }
  // 修改规则数据
  public async applicantRecordUpdate(param: any) {
    const result = await this.utils.post(
      '/applicantRecord/update',
      param
    );
    return this.utils.getActionResult(result);
  }
  // 删除规则数据
  public async ruleDataDelete(param: any) {
    const result = await this.utils.post(
      '/applicantRecord/delete',
      param
    );
    return this.utils.getActionResult(result);
  }
  // 查询规则数据
  public async ruleDataList(
    query: any,
    pageIndex: number,
    pageSize: number,
    orderBys?: OrderBy[]
  ) {
    const result = await this.utils.post(
      '/ruleData/list',
      qb.selectMore(query, qb.pager(pageIndex, pageSize), orderBys)
    );
    return this.utils.getActionResult(result);
  }
  // 列表&根据属性模糊查询包括草稿的所有规则数据
  public async ruleDataListListRuleDatasAndDraft(
    query: any,
    pageIndex: number,
    pageSize: number,
    orderBys?: OrderBy[]
  ) {
    const result = await this.utils.post(
      '/ruleData/listRuleDatasAndDraft',
      qb.selectMore(query, qb.pager(pageIndex, pageSize), orderBys)
    );
    return this.utils.getActionResult(result);
  }
  // 提交草稿审批&发布规则
  public async applicantRecordSubmitAndPublish(param: any) {
    const result = await this.utils.post(
      '/applicantRecord/submitAndPublish',
      param
    );
    return this.utils.getActionResult(result);
  }
  // 暂无用-审批规则修改申请
  public async ruleDataAudit(param: any) {
    const result = await this.utils.post(
      '/ruleData/audit',
      param
    );
    return this.utils.getActionResult(result);
  }
  // 暂无用-查询规则详情
  public async ruleDetail(param: any) {
    const result = await this.utils.post(
      '/rule/detail',
      param
    );
    return this.utils.getActionResult(result);
  }
  // 根据规则名称和调整理由查询 要审批的数据
  public async applicantRecordlookup(
    query: any,
    pageIndex: number,
    pageSize: number,
    orderBys?: OrderBy[]
  ) {
    const result = await this.utils.post(
      '/applicantRecord/lookup',
      qb.selectMore(query, qb.pager(pageIndex, pageSize), orderBys)
    );
    return this.utils.getActionResult(result);
  }
  // 查询逻辑符号
  public async logicalList(param: any) {
    const result = await this.utils.post(
      '/logical/list',
      param
    );
    return this.utils.getActionResult(result);
  }
  // 规则数据撤销修改
  public async applicantRecordCancel(param: any) {
    const result = await this.utils.post(
      '/applicantRecord/cancel',
      param
    );
    return this.utils.getActionResult(result);
  }
  // 确认调整
  public async ruleDraftPass(param: any) {
    const result = await this.utils.post(
      '/ruleDraft/pass',
      param
    );
    return this.utils.getActionResult(result);
  }
  // 拒绝调整
  public async ruleDraftReject(param: any) {
    const result = await this.utils.post(
      '/ruleDraft/reject',
      param
    );
    return this.utils.getActionResult(result);
  }
  // 根据草稿箱ID查询草稿数据
  public async applicantRecordlistDraftDataById(
    query: any,
    pageIndex: number,
    pageSize: number,
    orderBys?: OrderBy[]
  ) {
    const result = await this.utils.post(
      '/applicantRecord/listDraftDataById',
      qb.selectMore(query, qb.pager(pageIndex, pageSize), orderBys)
    );
    return this.utils.getActionResult(result);
  }
  // 根据ruleId查询规则属性
    public async selectRuleAttrByRuleId(param: any) {
      const result = await this.utils.post(
        '/ruleAttr/selectRuleAttrByRuleId',
        param
      );
      return this.utils.getActionResult(result);
    }
  // ruleAttr/selectRuleAttrList
    public async selectRuleAttrList(param: any) {
      const result = await this.utils.post(
        '/ruleAttr/selectRuleAttrList',
        param
      );
      return this.utils.getActionResult(result);
    }
  // 查询规则列表
    public async ruleSelectLists(param: any) {
      const result = await this.utils.post(
        '/rule/selectLists',
        param
      );
      return this.utils.getActionResult(result);
    }
    //selectRuleAttrDataListByAttrId
    public async selectRuleAttrDataListByAttrId(param: any) {
      const result = await this.utils.post(
        '/ruleAttrData/selectRuleAttrDataListByAttrId',
        param
      );
      return this.utils.getActionResult(result);
    }
}

