import Utils from '../../utils';
import qb, { OrderBy } from '../../query-builder';
export default class {
  private utils: any;
  constructor(apiPath: string) {
    this.utils = new Utils(apiPath);
  }
  // 分页查询列表
  public async ruleAttrDataPageList(query: any, pageIndex: number, pageSize: number, orderBys?: OrderBy[]) {
    const result = await this.utils.post(
      '/ruleAttrData/selectRuleAttrDataPageList',
      qb.selectMore(query, qb.pager(pageIndex, pageSize), orderBys)
    );
    return this.utils.getActionResult(result);
  }
  // attr_id查询
  public async selectRuleAttrDataByAttrId(query: any, pageIndex: number, pageSize: number, orderBys?: OrderBy[]) {
    const result = await this.utils.post(
      '/ruleAttrData/selectRuleAttrDataByAttrId',
      qb.selectMore(query, qb.pager(pageIndex, pageSize), orderBys)
    );
    return this.utils.getActionResult(result);
  }
  // id查询列表
  public async selectRuleAttrDataById(id: any) {
    const result = await this.utils.post('/ruleAttrData/selectRuleAttrDataById?id=' + id);
    return this.utils.getActionResult(result);
  }
  // 新增
  public async saveRuleAttrData(param: any) {
    const result = await this.utils.post('/ruleAttrData/saveRuleAttrData', param);
    return this.utils.getActionResult(result);
  }
  // 更新
  public async updateTagData(param: any) {
    const result = await this.utils.post('/ruleAttrData/updateRuleAttrData', param);
    return this.utils.getActionResult(result);
  }
  // 删除
  public async delRuleAttrDataById(param: any) {
    const result = await this.utils.post('/ruleAttrData/delRuleAttrDataById?id=' + param);
    return this.utils.getActionResult(result);
  }
}
