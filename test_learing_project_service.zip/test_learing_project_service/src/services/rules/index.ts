import RuleattrService from './RuleattrService';
import RuleattrdataService from './RuleattrdataService';
import RuleroleService from './RuleroleService';
import RuleroleuserService from './RuleroleuserService';
import RuleManagementService from './RuleManagementService';

const apiPath: any = process.env.VUE_APP_API_RULE;
const ruleattrService = new RuleattrService(apiPath);
const ruleattrdataService = new RuleattrdataService(apiPath);
const ruleroleService = new RuleroleService(apiPath);
const ruleroleuserService = new RuleroleuserService(apiPath);
const ruleManagementService =  new RuleManagementService(apiPath);
export {
  RuleattrService,
  RuleattrdataService,
  RuleroleService,
  RuleroleuserService,
  RuleManagementService,
  ruleattrService,
  ruleattrdataService,
  ruleroleService,
  ruleroleuserService,
  ruleManagementService,
};
