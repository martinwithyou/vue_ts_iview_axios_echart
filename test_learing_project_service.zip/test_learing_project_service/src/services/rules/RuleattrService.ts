import Utils from '../../utils';
import qb, { OrderBy } from '../../query-builder';

export default class {
  private utils: any;
  constructor(apiPath: string) {
    this.utils = new Utils(apiPath);
  }
  // 条件查询列表
  public async ruleAttrPageList(
    query: any,
    pageIndex: number,
    pageSize: number,
    orderBys?: OrderBy[]
  ) {
    const result = await this.utils.post(
      '/ruleAttr/selectRuleAttrPageList',
      qb.selectMore(query, qb.pager(pageIndex, pageSize), orderBys)
    );
    return this.utils.getActionResult(result);

  }
  // id查询列表
  public async selectRuleAttrById(id: any) {
    const result = await this.utils.post(
      ' /ruleAttr/selectRuleAttrById?id=' + id
    );
    return this.utils.getActionResult(result);

  }
  // 新增
  public async addRuleAttr(param: any) {
    const result = await this.utils.post('/ruleAttr/addRuleAttr', param);
    return this.utils.getActionResult(result);

  }
  // 更新
  public async updateRuleAttr(param: any) {
    const result = await this.utils.post('/ruleAttr/updateRuleAttr', param);
    return this.utils.getActionResult(result);

  }
  // 删除
  public async delRuleAttrById(param: any) {
    const result = await this.utils.post(
      '/ruleAttr/delRuleAttrById?id=' + param
    );
    return this.utils.getActionResult(result);

  }
}
