import FlowTypeService from './FlowTypeService';
import FixflowGroupService from './FixflowGroupService';
import FixflowHistoryService from './FixflowHistoryService';
import FixflowManageService from './FixflowManageService';
import FixflowPreviewService from './FixflowPreviewService';
import FixflowVirtualRuntime from './FixflowVirtualRuntime';
import FixflowAppIdManagmentService from './FixflowAppIdManagmentService';

const apiPath:any = process.env.VUE_APP_API_PUBLISH;
// alert(apiPath);
const flowTypeService = new FlowTypeService(apiPath);
const fixflowGroupService = new FixflowGroupService(apiPath);
const fixflowHistoryService = new FixflowHistoryService(apiPath);
const fixflowManageService = new FixflowManageService(apiPath);
const fixflowPreviewService = new FixflowPreviewService(apiPath);
const fixflowVirtualRuntime = new FixflowVirtualRuntime(apiPath);
const fixflowAppIdManagmentService = new FixflowAppIdManagmentService(apiPath);
export {
  FlowTypeService,
  FixflowGroupService,
  FixflowHistoryService,
  FixflowManageService,
  FixflowPreviewService,
  FixflowVirtualRuntime,
  FixflowAppIdManagmentService,
  flowTypeService,
  fixflowGroupService,
  fixflowHistoryService,
  fixflowManageService,
  fixflowPreviewService,
  fixflowVirtualRuntime,
  fixflowAppIdManagmentService,
};
