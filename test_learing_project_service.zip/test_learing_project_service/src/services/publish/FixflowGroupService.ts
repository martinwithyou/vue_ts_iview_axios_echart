import Utils from '../../utils';
import qb, { OrderBy } from '../../query-builder';

export default class {
  private utils: any;
  constructor(apiPath: string) {
    this.utils = new Utils(apiPath);
    // alert(apiPath);
  }
  // id查询列表
  public async selectRuleAttrDataById(id: any) {
    const result = await this.utils.post('/ruleAttrData/selectRuleAttrDataById?id=' + id);
    return this.utils.getActionResult(result);
  }
  
}
