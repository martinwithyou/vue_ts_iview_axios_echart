import Utils from '../../utils';
import qb, { OrderBy } from '../../query-builder';
import axios from 'axios';
const serverPath: any = process.env.VUE_APP_API_PUBLISH;
export default class {
  private utils: any;
  constructor(apiPath: string) {
    this.utils = new Utils(apiPath);
  }

  // SSO获取用户信息
  public async getUserInfo(params: any) {
    const result = await this.utils.get('/user/getUserInfo', params);
    return result;
  }
  // 登陆接口
  public async loginByUser(params: any) {
    const result = await this.utils.post('/user/loginByUser', params);
    return result;
  }

}
