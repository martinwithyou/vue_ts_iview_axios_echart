import Utils from '../../utils';
import qb, { OrderBy } from '../../query-builder';
const serverPath:any = process.env.VUE_APP_API_PUBLISH;
export default class {
  private utils: any;
  constructor(apiPath: string) {
    this.utils = new Utils(apiPath);
  }
  
}
