import Vue from 'vue';
import App from './App.vue';
import router from './router';
import store from './store';
import iView from 'iview';
import Vuex from 'vuex';
import 'iview/dist/styles/iview.css';
import {
  flowTypeService,
  fixflowGroupService,
  fixflowHistoryService,
  fixflowManageService,
  fixflowPreviewService,
  fixflowVirtualRuntime,
  fixflowAppIdManagmentService,
} from '@/services/publish';
import {
  userService,
  processService,
  taskService,
  commandService,
  logService,
  employeeService,
  dimissionService,
} from '@/services/manage';
import {
  ruleattrService,
  ruleattrdataService,
  ruleroleService,
  ruleroleuserService,
  ruleManagementService
} from '@/services/rules';
Vue.config.productionTip = false;

Vue.use(iView, {
  transfer: true,
  size: 'large',
});
Vue.use(Vuex);

const v = new Vue({
  router,
  render: (h: any) => h(App),
  provide: {
    flowTypeService,
    fixflowGroupService,
    fixflowHistoryService,
    fixflowManageService,
    fixflowPreviewService,
    fixflowVirtualRuntime,
    fixflowAppIdManagmentService,
    userService,
    processService,
    taskService,
    commandService,
    logService,
    employeeService,
    dimissionService,
    ruleattrService,
    ruleattrdataService,
    ruleroleService,
    ruleroleuserService,
    ruleManagementService
  },
  store,
}).$mount('#app');

