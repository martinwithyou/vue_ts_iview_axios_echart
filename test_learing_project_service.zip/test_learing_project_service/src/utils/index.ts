import axios from 'axios';
const serverPath: any = process.env.VUE_APP_API_RULE;
function getInstance(serverPath: string) {
  const http = axios.create({
    baseURL: serverPath,
    timeout: 50000,
  });
  /* request拦截器 */
  http.interceptors.request.use(
    (config: any) => {
      return config;
    },
    (error: any) => {
      Promise.reject(error);
    }
  );
  /* respone拦截器 */
  http.interceptors.response.use(
    (res: any) => {
      if (res.code !== '000000') {
        return Promise.resolve(res);
      }
      if (res.data instanceof Blob) {
        return res;
      }
    },
    (error: any) => {
      if (error.response && `${error.response.status}` === '403') {
        const url = `${serverPath}/#/401`;
        window.location.href = url;
      } else {
        return Promise.reject(error);
      }
    }
  );
  return http;
}

export default class {
  private apiPath: string = '';
  constructor(apiPath: string) {
    this.apiPath = apiPath;
  }
  // 测试环境
  public async post(url: string, data: any) {
    const result = await getInstance(this.apiPath).post(url, data);
    return result.data;
  }
  public async get(url: string, param: any) {
    const result = await getInstance(this.apiPath).get(url, {
      params: param,
    });
    return result.data;
  }
  public getQueryResult(result: any) {
    if (result.code !== '000000') {
      return result;
    } else {
      return result.data;
    }
  }
  public async getActionResult(result: any) {
    if (result.code !== '000000') {
      return result;
    }else {
      return result;
    }
  }
}

